-- Replace XX with your initials or other unique identifier
insert into services (id, name, description, bindable) values ('Murali', 'Murali-HaaSh', 'HaaSh - HashMap as a Service', true)
insert into plans (id, name, description, service_id) values ('Muralir', 'basic', 'Basic Plan','Murali');
